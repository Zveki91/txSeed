create function fnc_check_hash_for_transaction(val integer) returns integer
    language plpgsql
as
$$
declare
    prev_tx_hash text;
    prev_tx_id   int;
    stringified_transaction       text;
    combined_string      text;
    hex_value text;
    hash_val  text;
    result    int;
begin

    select prev_id
    into prev_tx_id
    from (select id                         as id,
                 lag(id) over (order by id) as prev_id
          from transaction) x
    where val in (id);

    prev_tx_hash := (select hash_value
                  from transaction
                  where id = prev_tx_id);
    stringified_transaction := (select (k.*)::text from (select transaction_id, amount, balance_before, balance_after, virtual_balance_before,
                                 virtual_balance_after, bonus_balance_before, bonus_balance_after, transaction_type_id,
                                 transaction_date, wallet_id, comment, game_code, psp_id, apco_reference_id,
                                 exchange_rate_id, modified_on, modified_by, modified_by_user_id, real_percentage,
                                 bonus_percentage, session_id, original_transaction_id, approval_status,
                                 transaction_fee, original_amount, original_currency_id, game_hand_id,
                                 payment_account_id, bonus_amount, original_bonus_amount, original_bonus_before,
                                 original_bonus_after, original_balance_before, original_balance_after,
                                 transaction_provider_type_id, provider_transaction_id, skrill_unique_id, fee_amount,
                                 original_fee_amount, jackpot_contribution, satisfied_amount, process_automaticly,
                                 payment_profile_payment_method_id, client_api_id, triger_bonus_id, is_direct,
                                 payment_limit_profile_payment_limit_per_day_id, withdrawal_pending_time,
                                 withdrawal_premium_fee, is_admin, withdrawal_request_action_type, bank_name, is_paid,
                                 is_paid_date, group_guid, is_postponed, marked_as_suspicious,
                                 user_name,full_name,transaction_reason_type_id, gateway_fee_amount, original_gateway_fee_amount,
                                 game_fee_amount, original_game_fee_amount, transaction_class_id, b2d_ratio, b2r_ratio,
                                 ip_address, amount_to_settle, payment_currency_id, payment_currency_amount,
                                 provider_round_id, platform_id, number_of_combinations, payment_gateway_id,
                                 payment_method_id, transaction_user_bonus, sb_transactions_details, transaction_data,
                                 user_id, event_date, event_date_iso, browser, online_token,
                                 email_template_parameters, balance_details, transaction_details,
                                 is_from_end_game from transaction where id = val) as k);
    combined_string := concat(prev_tx_hash, stringified_transaction);
    hex_value := (encode(combined_string::bytea, 'hex'));
    hash_val := (replace(concat('0', (sha256(hex_value::bytea))), '\', ''));
              if(hash_val LIKE (select hash_value from transaction where id = val)) then result = 1;
             else result = 0;
          end if;
    RETURN result;
end;

$$;

alter function fnc_check_hash_for_transaction(integer) owner to postgres;

