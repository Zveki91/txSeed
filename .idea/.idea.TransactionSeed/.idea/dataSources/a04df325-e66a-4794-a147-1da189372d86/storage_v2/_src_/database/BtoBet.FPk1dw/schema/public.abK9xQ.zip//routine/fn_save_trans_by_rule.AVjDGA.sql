create function fn_save_trans_by_rule() returns trigger
    language plpgsql
as
$$
BEGIN
    IF (TG_OP = 'INSERT') THEN
    INSERT INTO reports.transaction_tax  (transaction_id, amount, balance_before, balance_after, virtual_balance_before, virtual_balance_after,
 bonus_balance_before, bonus_balance_after, transaction_type_id, transaction_date, wallet_id, comment, game_code, psp_id, apco_reference_id,
  exchange_rate_id, modified_on, modified_by, modified_by_user_id, real_percentage, bonus_percentage, session_id, original_transaction_id,
   approval_status, transaction_fee, original_amount, original_currency_id, game_hand_id, payment_account_id, bonus_amount, original_bonus_amount,
    original_bonus_before, original_bonus_after, original_balance_before, original_balance_after, transaction_provider_type_id, provider_transaction_id,
     skrill_unique_id, fee_amount, original_fee_amount, jackpot_contribution, satisfied_amount, process_automaticly, payment_profile_payment_method_id,
      client_api_id, triger_bonus_id, is_direct, payment_limit_profile_payment_limit_per_day_id, withdrawal_pending_time, withdrawal_premium_fee, is_admin,
       withdrawal_request_action_type, bank_name, is_paid, is_paid_date, group_guid, is_postponed, marked_as_suspicious, transaction_reason_type_id, gateway_fee_amount,
        original_gateway_fee_amount, game_fee_amount, original_game_fee_amount, transaction_class_id, b2d_ratio, b2r_ratio, ip_address, amount_to_settle, payment_currency_id,
         payment_currency_amount, provider_round_id, platform_id, number_of_combinations, user_name, hash_value, full_name, payment_gateway_id, payment_method_id, transaction_user_bonus,
          sb_transactions_details, transaction_data, user_id, event_date, event_date_iso, browser, online_token, email_template_parameters, balance_details, transaction_details,
           is_from_end_game)
    SELECT NEW.transaction_id,
NEW.amount,
NEW.balance_before,
NEW.balance_after,
NEW.virtual_balance_before,
NEW.virtual_balance_after,
NEW.bonus_balance_before,
NEW.bonus_balance_after,
NEW.transaction_type_id,
NEW.transaction_date,
NEW.wallet_id,
NEW.comment,
NEW.game_code,
NEW.psp_id,
NEW.apco_reference_id,
NEW.exchange_rate_id,
NEW.modified_on,
NEW.modified_by,
NEW.modified_by_user_id,
NEW.real_percentage,
NEW.bonus_percentage,
NEW.session_id,
NEW.original_transaction_id,
NEW.approval_status,
NEW.transaction_fee,
NEW.original_amount,
NEW.original_currency_id,
NEW.game_hand_id,
NEW.payment_account_id,
NEW.bonus_amount,
NEW.original_bonus_amount,
NEW.original_bonus_before,
NEW.original_bonus_after,
NEW.original_balance_before,
NEW.original_balance_after,
NEW.transaction_provider_type_id,
NEW.provider_transaction_id,
NEW.skrill_unique_id,
NEW.fee_amount,
NEW.original_fee_amount,
NEW.jackpot_contribution,
NEW.satisfied_amount,
NEW.process_automaticly,
NEW.payment_profile_payment_method_id,
NEW.client_api_id,
NEW.triger_bonus_id,
NEW.is_direct,
NEW.payment_limit_profile_payment_limit_per_day_id,
NEW.withdrawal_pending_time,
NEW.withdrawal_premium_fee,
NEW.is_admin,
NEW.withdrawal_request_action_type,
NEW.bank_name,
NEW.is_paid,
NEW.is_paid_date,
NEW.group_guid,
NEW.is_postponed,
NEW.marked_as_suspicious,
NEW.transaction_reason_type_id,
NEW.gateway_fee_amount,
NEW.original_gateway_fee_amount,
NEW.game_fee_amount,
NEW.original_game_fee_amount,
NEW.transaction_class_id,
NEW.b2d_ratio,
NEW.b2r_ratio,
NEW.ip_address,
NEW.amount_to_settle,
NEW.payment_currency_id,
NEW.payment_currency_amount,
NEW.provider_round_id,
NEW.platform_id,
NEW.number_of_combinations,
NEW.user_name,
NEW.hash_value,
NEW.full_name,
NEW.payment_gateway_id,
NEW.payment_method_id,
NEW.transaction_user_bonus,
NEW.sb_transactions_details,
NEW.transaction_data,
NEW.user_id,
NEW.event_date,
NEW.event_date_iso,
NEW.browser,
NEW.online_token,
NEW.email_template_parameters,
NEW.balance_details,
NEW.transaction_details,
NEW.is_from_end_game
    FROM brf.rule_set rs
    INNER JOIN brf.vw_rule r ON rs.id = r.rule_set_id
    WHERE 1=1
        AND NEW.modified_on BETWEEN rs.valid_from and rs.valid_to
        AND NEW.transaction_type_id = rs.transaction_type_id
        AND (COALESCE(CAST(NEW.approval_status AS varchar),'{}') = CAST(rs.approval_status AS varchar)
           OR NEW.approval_status = ANY (rs.approval_status::int[]))
        AND (r.amount IS NULL OR NEW.amount > CAST(r.amount AS numeric))
        AND (r.marked_as_suspicious IS NULL OR NEW.marked_as_suspicious = CAST(r.marked_as_suspicious AS boolean));
    END IF;
RETURN NULL;
END;
$$;

alter function fn_save_trans_by_rule() owner to postgres;

