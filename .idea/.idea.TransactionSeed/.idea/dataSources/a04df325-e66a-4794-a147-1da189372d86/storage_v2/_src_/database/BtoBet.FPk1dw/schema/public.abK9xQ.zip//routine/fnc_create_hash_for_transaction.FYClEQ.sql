create function fnc_create_hash_for_transaction() returns trigger
    language plpgsql
as
$$
declare
    prev_tx_hash text;
    stringified_tranasction       text;
    combined_string    text;
    hex_value text;
begin


    prev_tx_hash := (select hash_value
                  from transaction
                  where id = (select id from transaction group by id order by id desc limit 1)) as t;
    stringified_tranasction := (select (NEW.transaction_id, NEW.amount, NEW.balance_before, NEW.balance_after, NEW.virtual_balance_before,
                                 NEW.virtual_balance_after, NEW.bonus_balance_before, NEW.bonus_balance_after, NEW.transaction_type_id,
                                 NEW.transaction_date, NEW.wallet_id, NEW.comment, NEW.game_code, NEW.psp_id, NEW.apco_reference_id,
                                 NEW.exchange_rate_id, NEW.modified_on, NEW.modified_by, NEW.modified_by_user_id, NEW.real_percentage,
                                 NEW.bonus_percentage, NEW.session_id, NEW.original_transaction_id, NEW.approval_status,
                                 NEW.transaction_fee, NEW.original_amount, NEW.original_currency_id, NEW.game_hand_id,
                                 NEW.payment_account_id, NEW.bonus_amount, NEW.original_bonus_amount, NEW.original_bonus_before,
                                 NEW.original_bonus_after, NEW.original_balance_before, NEW.original_balance_after,
                                 NEW.transaction_provider_type_id, NEW.provider_transaction_id, NEW.skrill_unique_id, NEW.fee_amount,
                                 NEW.original_fee_amount, NEW.jackpot_contribution, NEW.satisfied_amount, NEW.process_automaticly,
                                 NEW.payment_profile_payment_method_id, NEW.client_api_id, NEW.triger_bonus_id, NEW.is_direct,
                                 NEW.payment_limit_profile_payment_limit_per_day_id, NEW.withdrawal_pending_time,
                                 NEW.withdrawal_premium_fee, NEW.is_admin, NEW.withdrawal_request_action_type, NEW.bank_name, NEW.is_paid,
                                 NEW.is_paid_date, NEW.group_guid, NEW.is_postponed, NEW.marked_as_suspicious,
                                 NEW.user_name,NEW.full_name,NEW.transaction_reason_type_id, NEW.gateway_fee_amount, NEW.original_gateway_fee_amount,
                                 NEW.game_fee_amount, NEW.original_game_fee_amount, NEW.transaction_class_id, NEW.b2d_ratio, NEW.b2r_ratio,
                                 NEW.ip_address, NEW.amount_to_settle, NEW.payment_currency_id, NEW.payment_currency_amount,
                                 NEW.provider_round_id, NEW.platform_id, NEW.number_of_combinations, NEW.payment_gateway_id,
                                 NEW.payment_method_id, NEW.transaction_user_bonus, NEW.sb_transactions_details, NEW.transaction_data,
                                 NEW.user_id, NEW.event_date, NEW.event_date_iso, NEW.browser, NEW.online_token,
                                 NEW.email_template_parameters, NEW.balance_details, NEW.transaction_details,
                                 NEW.is_from_end_game)::text);
    combined_string := concat(prev_tx_hash, stringified_tranasction);
    hex_value := (encode(combined_string::bytea, 'hex'));
    NEW.hash_value := (replace(concat('0', (sha256(hex_value::bytea))), '\', ''));
    RETURN NEW;
end;

$$;

alter function fnc_create_hash_for_transaction() owner to postgres;

